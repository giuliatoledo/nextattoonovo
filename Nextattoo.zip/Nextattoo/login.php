<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>Nextattoo</title>
  <link rel="shortcut icon" href="fav.jpg" type="image/x-icon"/>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css"  href="style.css" />	
    <body>
    <center>
	<header><img class="logotipo" src="nxt.png"></header>

<?php

$name= $_POST['name'];
$email= $_POST['email'];
$senha= $_POST['password'];

$emailValido = "contato@nextattoo.com.br";
$senhaValida = "1234";

if($email == $emailValido){
	if($senha == $senhaValida){
		echo "<font color='white'><h4>Dados corretos! :)</font></h4><br>";
	} else {
		echo "<font color='white'><h4>Tente novamente...<br>Senha incorreta! :( </font></h4><br>";
	}
} else {
	echo "<font color='white'><h4>Ops... e-mail inválido.</font></h4><br>";
}

/*Form1

include_once 'formulario.php';
$form1 = new form ('Somos +10.000 profissionais', 'Estamos presentes em 10 estados','Encontre +100.000 tatuagens para se inspirar', 'Somos a Nextattoo');

echo "<br><b><h4><i>Desde 2018 atuando no mercado e hoje</i></h4><BR></b>";
	echo "<br>".$form1->getinfo1();
	echo "<br>".$form1->getinfo2();
	echo "<br>".$form1->getinfo3();
	echo "<br>".$form1->getinfo4();
<br><br>
<input type="submit" class="btn btn-success" value="Continuar"/>
*/

?>
</body>
</head>
</html>
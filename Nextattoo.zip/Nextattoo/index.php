<?php

/**
 * Aqui teríamos algum código para
 * recuperar de uma fonte de dados
 * as informações do formulário.
 *
 * Utilizaremos o código abaixo, apenas como fins ilustrativo,
 * imaginando que ele vem de alguma fonte.
 */
$tatuador = (bool) rand(0, 1) ? "checked" : null;
$cliente  = (bool) rand(0, 1) ? "checked" : null;

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Nextattoo</title>
  <link rel="shortcut icon" href="fav.jpg" type="image/x-icon"/>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css"  href="style.css" />
</head>

  <body>
  <center>

  <header><img class="logotipo" src="nxt.png"></header>

<div class="container">
  <div class="row">
    <div class="col-sm">
        <div class="form-group">
          <h3> Seja bem-vindo a Nextattoo! <br></h3>
          <h6>Diga-nos o que você está procurando.</h6><br>

<!--Inicio do Formulario-->
<!--Criação do Checkbox para escolher entre conta tatuador ou cliente -->

<form action="form-action.php" method="post">
             <h4>
            <p>
                <input type="checkbox" name="tatuador" value="on" <?php echo $tatuador; ?> > <font color='white'> Sou tatuador!</font>
            </p>
            <p>
                <input type="checkbox" name="cliente" value="on" <?php echo $cliente; ?> > <font color='white'>Sou cliente e quero achar minha <b>#NEXTATTOO!</b></font></h4>
            </p>
            <p>
                <input type="submit" class="btn btn-success" value="Continuar"/>
            </p>
        </form>

</body>
</html>

